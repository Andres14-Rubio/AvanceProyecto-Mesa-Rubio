/**
 * Clase Cup
 * Representa una taza dentro de la torre.
 * Implementa la interfaz StackingItem.
 * 
 * Ahora en el Ciclo 2 puede estar tapada.
 */
public class Cup implements StackingItem {

    private int number;              // Número identificador de la taza
    private int heightCm;            // Altura en centímetros
    private Rectangle body;          // Representación gráfica
    private boolean visible;         // Indica si está visible en pantalla

    private boolean covered;         // Indica si la taza está tapada (Ciclo 2)
    private String originalColor;    // Guarda el color original

    public static final int PX_PER_CM = 10;  // Conversión gráfica

    private int currentX;            // Posición X actual
    private int currentY;            // Posición Y actual

    /**
     * Constructor de la taza.
     * @param number número identificador
     * @param heightCm altura en centímetros
     * @param color color inicial
     */
    public Cup(int number, int heightCm, String color) {
        this.number = number;
        this.heightCm = heightCm;

        body = new Rectangle();
        originalColor = color;           // Guardamos el color original
        body.changeColor(color);
        body.changeSize(heightCm * PX_PER_CM, 40);

        // Ajuste inicial del rectángulo a (0,0)
        body.moveHorizontal(-70);
        body.moveVertical(-15);
        currentX = 0;
        currentY = 0;

        visible = false;
        covered = false;                 // Inicialmente no está tapada
    }

    @Override
    public int getNumber() { return number; }

    @Override
    public String getType() { return "cup"; }

    @Override
    public int getHeightCm() { return heightCm; }

    /**
     * Mueve la taza a una posición específica.
     */
    @Override
    public void moveTo(int x, int baseY) {
        int topY = baseY - (heightCm * PX_PER_CM);

        body.moveHorizontal(x - currentX);
        body.moveVertical(topY - currentY);

        currentX = x;
        currentY = topY;
    }

    @Override
    public void makeVisible() {
        if(!visible) {
            body.makeVisible();
            visible = true;
        }
    }

    @Override
    public void makeInvisible() {
        if(visible) {
            body.makeInvisible();
            visible = false;
        }
    }

    // ================================
    // MÉTODOS CICLO 2
    // ================================

    /**
     * Marca la taza como tapada y cambia su color
     * para que visualmente luzca diferente.
     */
    public void cover() {
        covered = true;
        body.changeColor("gray"); // Color cuando está tapada
    }

    /**
     * Quita la tapa visualmente.
     */
    public void uncover() {
        covered = false;
        body.changeColor(originalColor);
    }

    /**
     * Indica si la taza está tapada.
     */
    public boolean isCovered() {
        return covered;
    }
}