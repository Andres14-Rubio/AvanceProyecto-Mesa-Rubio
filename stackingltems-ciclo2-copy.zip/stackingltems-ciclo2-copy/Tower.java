import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;

public class Tower {

    private int width;
    private int maxHeight;

    private boolean visible;
    private boolean covered;
    private String originalColor;
    private boolean lastOk;

    private ArrayList<StackingItem> stack;

    private HashSet<Integer> cupNums;
    private HashSet<Integer> lidNums;
    private HashMap<Integer, String> cupColor;

    // marcas de centímetros (derecha)
    private ArrayList<Rectangle> cmMarks;

    // posición en pantalla (puedes ajustar)
    private int xBase = 120;
    private int yFloor = 350;
    

    public Tower(int width, int maxHeight) {
        this.width = width;
        this.maxHeight = maxHeight;

        visible = false;
        lastOk = true;

        stack = new ArrayList<>();
        cupNums = new HashSet<>();
        lidNums = new HashSet<>();
        cupColor = new HashMap<>();

        cmMarks = new ArrayList<>();
    }

    // ---- Estado ----
    public boolean ok() { return lastOk; }

    // ---- Visible / Invisible ----
    public void makeVisible() {
        visible = true;
        redraw();
    }

    public void makeInvisible() {
        visible = false;

        for(StackingItem it : stack) it.makeInvisible();

        // ocultar marcas
        for(Rectangle r : cmMarks) r.makeInvisible();
        cmMarks.clear();
    }

    // ---- Altura ----
    public int height() {
        int h = 0;
        for(StackingItem it : stack) h += it.getHeightCm();
        return h;
    }

    // ---- PUSH ----
    public void pushCup(int i) {
        lastOk = false;
        if(cupNums.contains(i)) return;

        int cupHeight = 8; // cm para que se vea bien
        if(height() + cupHeight > maxHeight) return;

        String color = pickColor(i);
        Cup cup = new Cup(i, cupHeight, color);

        stack.add(cup);
        cupNums.add(i);
        cupColor.put(i, color);

        lastOk = true;
        redraw();
    }

    public void pushLid(int i) {
        lastOk = false;
        if(lidNums.contains(i)) return;

        if(height() + 1 > maxHeight) return;

        String color = cupColor.containsKey(i) ? cupColor.get(i) : "black";
        Lid lid = new Lid(i, color);

        int cupIndex = indexOfCup(i);
        if(cupIndex != -1) {
            stack.add(cupIndex + 1, lid); // justo encima de su taza
        } else {
            stack.add(lid);               // si no existe taza, arriba
        }

        lidNums.add(i);
        lastOk = true;
        redraw();
    }

    // ---- POP ----
    public void popCup() {
        lastOk = false;
        if(stack.isEmpty()) return;

        for(int i = stack.size() - 1; i >= 0; i--) {
            if(stack.get(i).getType().equals("cup")) {

                int number = stack.get(i).getNumber();

                // si está tapada, quitar también tapa
                if(isLided(number)) {
                    StackingItem lid = stack.get(i + 1);
                    lid.makeInvisible();
                    stack.remove(i + 1);
                    lidNums.remove(number);
                }

                StackingItem cup = stack.get(i);
                cup.makeInvisible();
                stack.remove(i);

                cupNums.remove(number);
                cupColor.remove(number);

                lastOk = true;
                redraw();
                return;
            }
        }
    }

    public void popLid() {
        lastOk = false;
        if(stack.isEmpty()) return;

        for(int i = stack.size() - 1; i >= 0; i--) {
            if(stack.get(i).getType().equals("lid")) {
                int number = stack.get(i).getNumber();

                stack.get(i).makeInvisible();
                stack.remove(i);
                lidNums.remove(number);

                lastOk = true;
                redraw();
                return;
            }
        }
    }

    // ---- REMOVE ----
    public void removeCup(int i) {
        lastOk = false;

        int idx = indexOfCup(i);
        if(idx == -1) return;

        if(isLided(i)) {
            StackingItem lid = stack.get(idx + 1);
            lid.makeInvisible();
            stack.remove(idx + 1);
            lidNums.remove(i);
        }

        StackingItem cup = stack.get(idx);
        cup.makeInvisible();
        stack.remove(idx);

        cupNums.remove(i);
        cupColor.remove(i);

        lastOk = true;
        redraw();
    }

    public void removeLid(int i) {
        lastOk = false;

        for(int idx = 0; idx < stack.size(); idx++) {
            StackingItem it = stack.get(idx);
            if(it.getType().equals("lid") && it.getNumber() == i) {

                it.makeInvisible();
                stack.remove(idx);
                lidNums.remove(i);

                lastOk = true;
                redraw();
                return;
            }
        }
    }

    // ---- CONSULTAS ----
    public String[][] stackingItems() {
        String[][] out = new String[stack.size()][2];
        for(int i = 0; i < stack.size(); i++) {
            out[i][0] = stack.get(i).getType();
            out[i][1] = "" + stack.get(i).getNumber();
        }
        return out;
    }

    public int[] lidedCups() {
        ArrayList<Integer> nums = new ArrayList<>();

        for(int i = 0; i < stack.size() - 1; i++) {
            StackingItem a = stack.get(i);
            StackingItem b = stack.get(i + 1);

            if(a.getType().equals("cup") &&
               b.getType().equals("lid") &&
               a.getNumber() == b.getNumber()) {
                nums.add(a.getNumber());
            }
        }

        Collections.sort(nums, Collections.reverseOrder());

        int[] out = new int[nums.size()];
        for(int k = 0; k < nums.size(); k++) out[k] = nums.get(k);
        return out;
    }

    // ---- ORDER / REVERSE (simple, compila) ----
    public void reverseTower() {
        lastOk = true;
        if(visible) for(StackingItem it : stack) it.makeInvisible();
        Collections.reverse(stack);
        redraw();
    }

    public void orderTower() {
        lastOk = true;
        if(visible) for(StackingItem it : stack) it.makeInvisible();

        Collections.sort(stack, (a, b) -> {
            int na = a.getNumber();
            int nb = b.getNumber();
            if(na != nb) return Integer.compare(na, nb);
            // mismo número: cup abajo, lid arriba
            if(a.getType().equals(b.getType())) return 0;
            return a.getType().equals("cup") ? -1 : 1;
        });

        redraw();
    }

    // ---- Salir ----
    public void exit() {
        System.exit(0);
    }

    // ---- (Opcional) imprimir estado para revisar ----
    public void printState() {
        System.out.println("ok=" + ok() + " height=" + height());
        String[][] s = stackingItems();
        for(int i = 0; i < s.length; i++) {
            System.out.println(i + ": " + s[i][0] + " " + s[i][1]);
        }
        int[] lc = lidedCups();
        System.out.print("lidedCups: ");
        for(int n : lc) System.out.print(n + " ");
        System.out.println();
    }

    // ---- Helpers ----
    private void redraw() {

        // ocultar items para evitar “fantasmas”
        if(visible) {
            for(StackingItem it : stack) it.makeInvisible();
        }

        int baseY = yFloor;

        for(StackingItem it : stack) {
            it.moveTo(xBase, baseY);
            if(visible) it.makeVisible();
            baseY -= it.getHeightCm() * Cup.PX_PER_CM;
        }

        drawCmMarks(); // marcas cm a la derecha
    }

    private void drawCmMarks() {

        // borrar marcas anteriores
        for(Rectangle r : cmMarks) {
            r.makeInvisible();
        }
        cmMarks.clear();

        if(!visible) return;

        int markX = xBase + 60;  // derecha de la torre
        int baseY = yFloor;

        for(int cm = 0; cm <= maxHeight; cm++) {

            Rectangle mark = new Rectangle();
            mark.changeColor("black");

            // rayita horizontal
            int length = (cm % 5 == 0) ? 25 : 15;  // cada 5 cm más larga
            mark.changeSize(2, length);

            // reset a (0,0)
            mark.moveHorizontal(-70);
            mark.moveVertical(-15);

            int y = baseY - (cm * Cup.PX_PER_CM);

            mark.moveHorizontal(markX);
            mark.moveVertical(y);

            mark.makeVisible();
            cmMarks.add(mark);
        }
    }

    private int indexOfCup(int i) {
        for(int idx = 0; idx < stack.size(); idx++) {
            StackingItem it = stack.get(idx);
            if(it.getType().equals("cup") && it.getNumber() == i) return idx;
        }
        return -1;
    }

    private boolean isLided(int i) {
        int idx = indexOfCup(i);
        if(idx == -1) return false;

        if(idx + 1 < stack.size()) {
            StackingItem next = stack.get(idx + 1);
            return next.getType().equals("lid") && next.getNumber() == i;
        }
        return false;
    }

    private String pickColor(int i) {
        String[] colors = {"red","blue","green","yellow","magenta","black"};
        return colors[Math.abs(i) % colors.length];
    }


    /**
 * Crea una nueva torre con n tazas.
 * No incluye tapas.
 * Limpia completamente la torre anterior.
 * Requisito 10.
 */
public void create(int n) {

    lastOk = false;

    // Limpiar torre anterior
    makeInvisible();
    stack.clear();
    cupNums.clear();
    lidNums.clear();
    cupColor.clear();

    int cupHeight = 8;

    // Verificar que no exceda altura máxima
    if(n * cupHeight > maxHeight) return;

    // Crear las tazas
    for(int i = 1; i <= n; i++) {
        String color = pickColor(i);
        Cup cup = new Cup(i, cupHeight, color);

        stack.add(cup);
        cupNums.add(i);
        cupColor.put(i, color);
    }

    lastOk = true;
    redraw();
}
/**
 * Intercambia la posición de dos objetos en la torre.
 * Requisito 11.
 */
public void reorganize(int pos1, int pos2) {

    lastOk = false;

    // Validar posiciones
    if(pos1 < 0 || pos2 < 0 ||
       pos1 >= stack.size() || pos2 >= stack.size())
        return;

    Collections.swap(stack, pos1, pos2);

    lastOk = true;
    redraw();
}
/**
 * Reorganiza la torre colocando cada tapa
 * justo encima de su taza correspondiente.
 * Requisito 12.
 */
public void reorganize() {

    lastOk = false;

    for(int i = 0; i < stack.size() - 1; i++) {

        StackingItem current = stack.get(i);

        if(current.getType().equals("cup")) {

            int number = current.getNumber();

            for(int j = 0; j < stack.size(); j++) {

                if(stack.get(j).getType().equals("lid") &&
                   stack.get(j).getNumber() == number) {

                    // Mover tapa encima de la taza
                    StackingItem lid = stack.remove(j);
                    stack.add(i + 1, lid);

                    // Marcar taza como tapada
                    ((Cup) current).cover();
                    break;
                }
            }
        }
    }

    lastOk = true;
    redraw();
}
/**
 * Consulta qué intercambio reduciría la altura de la torre.
 * No modifica la torre permanentemente.
 * Requisito 13.
 * 
 * @return arreglo con las posiciones a intercambiar
 */
public int[] consult() {

    int currentHeight = height();

    for(int i = 0; i < stack.size(); i++) {
        for(int j = i + 1; j < stack.size(); j++) {

            // Probar intercambio temporal
            Collections.swap(stack, i, j);
            int newHeight = height();
            Collections.swap(stack, i, j);

            if(newHeight < currentHeight) {
                return new int[]{i, j};
            }
        }
    }

    return new int[]{-1, -1};
}
}