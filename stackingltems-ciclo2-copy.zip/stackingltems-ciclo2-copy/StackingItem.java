public interface StackingItem {
    int getNumber();
    String getType();       // "cup" o "lid"
    int getHeightCm();      // lid = 1
    void moveTo(int x, int baseY);  // posición absoluta usando baseY (piso de la pieza)
    void makeVisible();
    void makeInvisible();
}
