public class Lid implements StackingItem {

    private int number;
    private Rectangle lid;
    private boolean visible;

    public static final int PX_PER_CM = Cup.PX_PER_CM;

    private int currentX;
    private int currentY;

    public Lid(int number, String color) {
        this.number = number;

        lid = new Rectangle();
        lid.changeColor(color);
        lid.changeSize(1 * PX_PER_CM, 44);

        // reset a (0,0)
        lid.moveHorizontal(-70);
        lid.moveVertical(-15);
        currentX = 0;
        currentY = 0;

        visible = false;
    }

    @Override public int getNumber() { return number; }
    @Override public String getType() { return "lid"; }
    @Override public int getHeightCm() { return 1; }

    @Override
    public void moveTo(int x, int baseY) {
        int topY = baseY - PX_PER_CM;

        lid.moveHorizontal(x - currentX);
        lid.moveVertical(topY - currentY);

        currentX = x;
        currentY = topY;
    }

    @Override
    public void makeVisible() {
        if(!visible) {
            lid.makeVisible();
            visible = true;
        }
    }

    @Override
    public void makeInvisible() {
        if(visible) {
            lid.makeInvisible();
            visible = false;
        }
    }
}