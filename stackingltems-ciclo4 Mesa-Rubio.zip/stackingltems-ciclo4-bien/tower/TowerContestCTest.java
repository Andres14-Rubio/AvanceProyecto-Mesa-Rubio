package tower;

public class TowerContestCTest {

    public static void main(String[] args) {

        TowerContest contest = new TowerContest();

        System.out.println("Prueba 1:");
        System.out.println(contest.solve(3,3));

        System.out.println("Prueba 2:");
        System.out.println(contest.solve(4,6));

        System.out.println("Prueba 3:");
        System.out.println(contest.solve(5,10));

        System.out.println("Caso imposible:");
        System.out.println(contest.solve(3,100));

        System.out.println("Simulación:");
        contest.simulate(3,3);
    }
}
