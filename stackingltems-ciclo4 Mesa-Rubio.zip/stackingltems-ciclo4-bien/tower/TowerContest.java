package tower;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Ciclo 3 - Solución al problema Stacking Cups
 * Resuelve el problema de la maratón y simula la solución.
 * 
 * Problema: Dadas n tazas con alturas 1, 3, 5, ..., 2n-1,
 * encontrar un orden de apilamiento que produzca altura total h.
 */
public class TowerContest {

    /**
     * Devuelve las alturas en el orden en que deben ponerse
     * o "imposible" si no existe solución.
     * Requisito 14.
     */
    public String solve(int n, long h) {
        int[] order = findOrder(n, h);

        if (order == null) {
            return "imposible";
        }

        StringBuilder answer = new StringBuilder();
        for (int i = 0; i < order.length; i++) {
            int height = 2 * order[i] - 1;
            if (i > 0) {
                answer.append(" ");
            }
            answer.append(height);
        }
        return answer.toString();
    }

    /**
     * Simula la solución usando Tower.
     * Requisito 15.
     */
    public void simulate(int n, long h) {
        int[] order = findOrder(n, h);

        if (order == null) {
            System.out.println("imposible");
            return;
        }

        String solution = solve(n, h);
        System.out.println("Solución: " + solution);

        if (n > 15) {
            System.out.println("Demasiadas tazas para simular visualmente.");
            return;
        }

        Tower tower = new Tower(120, (int)h + 20);
        tower.makeVisible();

        // Apilar en orden inverso (la primera va al fondo)
        for (int i = 0; i < order.length; i++) {
            int cupNumber = order[i];
            int cupHeight = 2 * cupNumber - 1;
            tower.pushCup(cupNumber, cupHeight);
        }
        
        System.out.println("Altura real: " + tower.getCurrentHeightCm() + " cm");
    }

    /**
     * Encuentra el orden correcto de números de taza (1..n)
     * que produce altura h.
     */
    private int[] findOrder(int n, long h) {
        if (n <= 0) {
            return null;
        }

        long minHeight = 2L * n - 1;
        long maxHeight = 1L * n * n;

        if (h < minHeight || h > maxHeight) {
            return null;
        }

        // Caso imposible especial
        if (h == maxHeight - 2) {
            return null;
        }

        // Para n pequeño, usar fuerza bruta
        if (n <= 6) {
            return bruteForceSolve(n, h);
        }

        // Algoritmo constructivo
        return constructSolution(n, h);
    }

    /**
     * Construye la solución para n > 6.
     */
    private int[] constructSolution(int n, long h) {
        long maxPossible = 1L * n * n;
        long minPossible = 2L * n - 1;

        // Determinar si la taza n va al fondo o al tope
        // Si va al fondo: contribuye 1 a la altura
        // Si va al tope: contribuye 2n-1 a la altura
        
        long heightWithoutN = h - 1;  // Asumimos que va al fondo
        
        if (heightWithoutN >= 2L * (n - 1) - 1 && heightWithoutN <= 1L * (n - 1) * (n - 1)) {
            // Puede ir al fondo
            int[] sub = findOrder(n - 1, heightWithoutN);
            if (sub != null) {
                return prepend(n, sub);
            }
        }
        
        // Intentar al tope
        heightWithoutN = h - (2L * n - 1);
        if (heightWithoutN >= 2L * (n - 1) - 1 && heightWithoutN <= 1L * (n - 1) * (n - 1)) {
            int[] sub = findOrder(n - 1, heightWithoutN);
            if (sub != null) {
                return append(sub, n);
            }
        }

        return null;
    }

    /**
     * Fuerza bruta para n <= 6.
     */
    private int[] bruteForceSolve(int n, long h) {
        ArrayList<int[]> permutations = new ArrayList<>();
        generatePermutations(n, new boolean[n + 1], new int[n], 0, permutations);

        for (int[] perm : permutations) {
            if (calculateHeight(perm) == h) {
                return perm;
            }
        }
        return null;
    }

    /**
     * Genera todas las permutaciones de 1..n.
     */
    private void generatePermutations(int n, boolean[] used, int[] current, 
                                       int pos, ArrayList<int[]> result) {
        if (pos == n) {
            result.add(Arrays.copyOf(current, n));
            return;
        }

        for (int x = 1; x <= n; x++) {
            if (!used[x]) {
                used[x] = true;
                current[pos] = x;
                generatePermutations(n, used, current, pos + 1, result);
                used[x] = false;
            }
        }
    }

    /**
     * Calcula la altura total de una torre dado el orden de tazas.
     * Algoritmo correcto para Stacking Cups.
     */
    private long calculateHeight(int[] order) {
        if (order.length == 0) {
            return 0;
        }

        int n = order.length;
        long[] cupHeights = new long[n + 1];
        for (int i = 1; i <= n; i++) {
            cupHeights[i] = 2L * i - 1;
        }

        // Simular apilamiento
        long currentBase = 0;
        long maxHeight = 0;
        
        for (int i = 0; i < order.length; i++) {
            int cup = order[i];
            long cupHeight = cupHeights[cup];
            
            if (i > 0) {
                int prevCup = order[i - 1];
                if (cup < prevCup) {
                    // Taza más pequeña dentro de la anterior
                    currentBase += 1;
                } else {
                    // Taza más grande envolviendo
                    currentBase += cupHeights[prevCup];
                }
            }
            
            long top = currentBase + cupHeight;
            if (top > maxHeight) {
                maxHeight = top;
            }
        }
        
        return maxHeight;
    }

    private int[] append(int[] arr, int value) {
        int[] out = new int[arr.length + 1];
        System.arraycopy(arr, 0, out, 0, arr.length);
        out[arr.length] = value;
        return out;
    }

    private int[] prepend(int value, int[] arr) {
        int[] out = new int[arr.length + 1];
        out[0] = value;
        System.arraycopy(arr, 0, out, 1, arr.length);
        return out;
    }
}
