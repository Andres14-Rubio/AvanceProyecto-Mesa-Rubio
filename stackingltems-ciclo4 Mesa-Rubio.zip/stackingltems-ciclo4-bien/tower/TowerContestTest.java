package tower;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Pruebas de unidad para TowerContest (Ciclo 3)
 */
public class TowerContestTest {

    private TowerContest contest;

    @Before
    public void setUp() {
        contest = new TowerContest();
    }

    // =====================================================
    // SOLVE
    // =====================================================

    @Test
    public void solveShouldReturnSolutionWhenPossible() {

        String result = contest.solve(3,3);

        assertNotNull(result);
        assertFalse(result.isEmpty());
    }

    @Test
    public void solveShouldReturnImpossibleWhenNotPossible() {

        String result = contest.solve(3,100);

        assertNotNull(result);
    }

    // =====================================================
    // SIMULATE
    // =====================================================

    @Test
    public void simulateShouldRunWithoutErrors() {

        contest.simulate(3,3);

        assertTrue(true); // si no lanza excepción pasa
    }
}
