package tower;

import shapes.Rectangle;

/**
 * Taza de tipo jerárquica.
 * Al entrar a la torre, desplaza todos los objetos de menor tamaño.
 * Si logra llegar al fondo de la torre, no se deja quitar.
 * Se distingue visualmente por tener un borde inferior dorado.
 * 
 * 
 */
public class HierarchicalCup extends Cup {
    
    /** Borde decorativo para distinción visual */
    private Rectangle bottomBorder;
    
    /** Indica si la taza ha llegado al fondo */
    private boolean reachedBottom;
    
    /**
     * Constructor para TazaJerarquica.
     * @param number número identificador
     * @param heightCm altura en centímetros
     * @param color color inicial
     */
    public HierarchicalCup(int number, int heightCm, String color) {
        super(number, heightCm, color);
        this.reachedBottom = false;
        initializeDecoration();
    }
    
    /**
     * Inicializa la decoración visual distintiva.
     */
    private void initializeDecoration() {
        bottomBorder = new Rectangle();
        bottomBorder.changeColor("yellow");
        bottomBorder.changeSize(5, CUP_WIDTH + 10);
    }
    
    @Override
    protected void positionWallsRelative(int baseX, int baseY) {
        super.positionWallsRelative(baseX, baseY);
        if (bottomBorder != null) {
            bottomBorder.moveTo(baseX + INITIAL_OFFSET_X - 5, 
                               baseY + INITIAL_OFFSET_Y + heightPx);
        }
    }
    
    @Override
    public String getSubtype() {
        return "hierarchical";
    }
    
    @Override
    public boolean canBeRemoved() {
        return !reachedBottom;
    }
    
    @Override
    public boolean onEnter(Tower tower) {
        // Desplaza objetos más pequeños
        boolean bottomReached = tower.displaceSmallerObjects(this);
        this.reachedBottom = bottomReached;
        
        if (bottomReached) {
            // Cambia color para indicar que está bloqueada
            applyColorToWalls("orange");
        }
        
        return true;
    }
    
    /**
     * Verifica si la taza ha llegado al fondo.
     * @return true si llegó al fondo
     */
    public boolean hasReachedBottom() {
        return reachedBottom;
    }
    
    @Override
    public void makeVisible() {
        super.makeVisible();
        if (bottomBorder != null) {
            bottomBorder.makeVisible();
        }
    }
    
    @Override
    public void makeInvisible() {
        super.makeInvisible();
        if (bottomBorder != null) {
            bottomBorder.makeInvisible();
        }
    }
}