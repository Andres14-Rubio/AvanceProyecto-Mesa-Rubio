package tower;

/**
 * Tapa de tipo normal.
 * Comportamiento estándar sin características especiales.
 * 
 
 */
public class NormalLid extends Lid {
    
    /**
     * Constructor para TapaNormal.
     * @param number número identificador
     * @param color color de la tapa
     */
    public NormalLid(int number, String color) {
        super(number, color);
    }
    
    @Override
    public String getSubtype() {
        return "normal";
    }
    
    @Override
    public boolean canEnter(Tower tower) {
        return true;
    }
    
    @Override
    public boolean canBeRemoved(Tower tower) {
        return true;
    }
}