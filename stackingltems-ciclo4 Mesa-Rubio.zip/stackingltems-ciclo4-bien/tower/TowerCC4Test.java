package tower;

/**
 * Common test cases for Cycle 4.
 * This class is meant to be extended by all students with their specific tests.
 * 
 * @author DOPO-POOB Team
 * @version 4.0
 */
public class TowerCC4Test {

    protected Tower tower;

    /**
     * Sets up a clean tower.
     */
    public void setUp() {
        tower = new Tower(200, 150);
        tower.makeVisible();
    }

    /**
     * Test 1: Create tower with normal cups.
     */
    public void testCreateNormalCups() {
        System.out.println("=== Test 1: Create Normal Cups ===");
        tower.create(5);
        tower.printState();
        pause(2000);
    }

    /**
     * Test 2: Opener cup removes blocking lids.
     */
    public void testOpenerCup() {
        System.out.println("=== Test 2: Opener Cup ===");
        tower.pushCup(1, 8, "normal");
        tower.pushLid(2, "normal");
        tower.pushLid(3, "normal");
        tower.printState();
        pause(1000);
        
        System.out.println("Pushing opener cup...");
        tower.pushCup(4, 8, "opener");
        tower.printState();
        pause(2000);
    }

    /**
     * Test 3: Hierarchical cup displaces smaller cups.
     */
    public void testHierarchicalCup() {
        System.out.println("=== Test 3: Hierarchical Cup ===");
        tower.pushCup(1, 8, "normal");
        tower.pushCup(2, 8, "normal");
        tower.printState();
        pause(1000);
        
        System.out.println("Pushing hierarchical cup (larger)...");
        tower.pushCup(5, 8, "hierarchical");
        tower.printState();
        pause(2000);
    }

    /**
     * Test 4: Magic cup color animation.
     */
    public void testMagicCup() {
        System.out.println("=== Test 4: Magic Cup ===");
        tower.pushCup(1, 8, "magic");
        tower.printState();
        pause(1000);
        
        System.out.println("Covering magic cup...");
        tower.pushLid(1, "normal");
        System.out.println("Watch the color change!");
        pause(5000);
    }

    /**
     * Test 5: Fearful lid behavior.
     */
    public void testFearfulLid() {
        System.out.println("=== Test 5: Fearful Lid ===");
        
        System.out.println("Trying to push fearful lid without cup...");
        tower.pushLid(1, "fearful");
        System.out.println("Success: " + tower.ok());
        pause(1000);
        
        System.out.println("Adding cup and then fearful lid...");
        tower.pushCup(1, 8, "normal");
        tower.pushLid(1, "fearful");
        tower.printState();
        
        System.out.println("Trying to remove fearful lid...");
        tower.popLid();
        System.out.println("Success: " + tower.ok());
        pause(2000);
    }

    /**
     * Test 6: Crazy lid as base.
     */
    public void testCrazyLid() {
        System.out.println("=== Test 6: Crazy Lid ===");
        tower.pushCup(1, 8, "normal");
        tower.printState();
        pause(1000);
        
        System.out.println("Adding crazy lid...");
        tower.pushLid(1, "crazy");
        tower.printState();
        System.out.println("Crazy lid should be at the base!");
        pause(2000);
    }

    /**
     * Runs all common tests.
     */
    public void runAllTests() {
        setUp();
        testCreateNormalCups();
        clearAndPause();
        
        testOpenerCup();
        clearAndPause();
        
        testHierarchicalCup();
        clearAndPause();
        
        testMagicCup();
        clearAndPause();
        
        testFearfulLid();
        clearAndPause();
        
        testCrazyLid();
        
        System.out.println("=== All Common Tests Completed ===");
    }

    private void clearAndPause() {
        pause(2000);
        tower.makeInvisible();
        tower = new Tower(200, 150);
        tower.makeVisible();
        pause(500);
    }

    private void pause(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            // Ignore
        }
    }

    /**
     * Main method to run tests.
     */
    public static void main(String[] args) {
        TowerCC4Test test = new TowerCC4Test();
        test.runAllTests();
    }
}