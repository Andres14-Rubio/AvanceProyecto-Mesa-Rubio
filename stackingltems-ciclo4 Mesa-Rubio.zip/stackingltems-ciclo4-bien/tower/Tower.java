package tower;

import shapes.Rectangle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;

/**
 * Clase Torre - Gestiona una torre de tazas y tapas.
 * Refactorizada para soportar múltiples tipos de tazas y tapas.
 * 
 * 
 * 
 */
public class Tower {

    private int width;
    private int maxHeightCm;
    private int maxHeightPx;

    private boolean visible;
    private boolean lastOk;

    private ArrayList<StackingItem> stack;

    private HashSet<Integer> cupNums;
    private HashSet<Integer> lidNums;
    private HashMap<Integer, String> cupColors;

    // Marcas de centímetros (lado derecho)
    private ArrayList<Rectangle> cmMarks;

    // Posición en pantalla
    private int xBase;
    private int yFloor;
    
    // Colores disponibles
    private static final String[] COLORS = {"red", "blue", "green", "yellow", "magenta", "black"};

    /**
     * Constructor para Torre.
     * @param width ancho en píxeles 
     * @param maxHeightCm altura máxima en centímetros
     */
    public Tower(int width, int maxHeightCm) {
        this.width = width;
        this.maxHeightCm = maxHeightCm;
        this.maxHeightPx = maxHeightCm * Cup.PX_PER_CM;

        this.visible = false;
        this.lastOk = true;

        this.stack = new ArrayList<>();
        this.cupNums = new HashSet<>();
        this.lidNums = new HashSet<>();
        this.cupColors = new HashMap<>();

        this.cmMarks = new ArrayList<>();
        
        this.xBase = 120;
        this.yFloor = 350;
    }

    // ================================
    // MÉTODOS DE ESTADO
    // ================================

    /**
     * Retorna el estado de la última operación.
     * @return true si la última operación fue exitosa
     */
    public boolean ok() {
        return lastOk;
    }

    /**
     * Obtiene la altura actual de la torre en centímetros.
     * @return altura actual en cm
     */
    public int getCurrentHeightCm() {
        int h = 0;
        for (StackingItem it : stack) {
            h += it.getHeightCm();
        }
        return h;
    }

    // ================================
    // VISIBILIDAD
    // ================================

    /**
     * Hace visible la torre.
     */
    public void makeVisible() {
        visible = true;
        redraw();
    }

    /**
     * Hace invisible la torre.
     */
    public void makeInvisible() {
        visible = false;
        hideAllItems();
        hideAllMarks();
    }
    
    private void hideAllItems() {
        for (StackingItem it : stack) {
            it.makeInvisible();
        }
    }
    
    private void hideAllMarks() {
        for (Rectangle r : cmMarks) {
            r.makeInvisible();
        }
        cmMarks.clear();
    }

    // ================================
    // OPERACIONES BÁSICAS
    // ================================

    /**
     * Apila una taza normal en la torre.
     * @param number número de taza
     */
    public void pushCup(int number) {
        pushCup(number, 8, "normal");
    }
    
    /**
     * Apila una taza con altura especificada en la torre.
     * @param number número de taza
     * @param heightCm altura en centímetros
     */
    public void pushCup(int number, int heightCm) {
        pushCup(number, heightCm, "normal");
    }
    
    /**
     * Apila una taza del tipo especificado en la torre.
     * @param number número de taza
     * @param heightCm altura en centímetros
     * @param subtype "normal", "opener", "hierarchical", "magic"
     */
    public void pushCup(int number, int heightCm, String subtype) {
        lastOk = false;
        
        if (cupNums.contains(number)) {
            return;
        }

        if (getCurrentHeightCm() + heightCm > maxHeightCm) {
            return;
        }

        String color = pickColor(number);
        Cup cup = createCup(number, heightCm, color, subtype);
        
        // Verifica si la taza puede entrar
        if (!cup.onEnter(this)) {
            return;
        }

        stack.add(cup);
        cupNums.add(number);
        cupColors.put(number, color);

        lastOk = true;
        redraw();
    }
    
    /**
     * Crea una taza del subtipo especificado.
     */
    private Cup createCup(int number, int heightCm, String color, String subtype) {
        switch (subtype.toLowerCase()) {
            case "opener":
            case "abridora":
                return new OpenerCup(number, heightCm, color);
            case "hierarchical":
            case "jerarquica":
                return new HierarchicalCup(number, heightCm, color);
            case "magic":
            case "magica":
                return new MagicCup(number, heightCm, color);
            default:
                return new NormalCup(number, heightCm, color);
        }
    }

    /**
     * Apila una tapa normal en la torre.
     * @param number número de tapa (debe coincidir con taza)
     */
    public void pushLid(int number) {
        pushLid(number, "normal");
    }
    
    /**
     * Apila una tapa del tipo especificado en la torre.
     * @param number número de tapa
     * @param subtype "normal", "fearful", "crazy"
     */
    public void pushLid(int number, String subtype) {
        lastOk = false;
        
        if (lidNums.contains(number)) {
            return;
        }

        if (getCurrentHeightCm() + 1 > maxHeightCm) {
            return;
        }

        String color = cupColors.getOrDefault(number, "black");
        Lid lid = createLid(number, color, subtype);
        
        // Verifica si la tapa puede entrar
        if (!lid.canEnter(this)) {
            return;
        }
        
        lid.onEnter(this);

        // Para tapas locas, posiciona diferente
        if (lid instanceof CrazyLid) {
            // Tapa loca va a la base
            int cupIndex = indexOfCup(number);
            if (cupIndex != -1) {
                stack.add(cupIndex, lid);
            } else {
                stack.add(0, lid);
            }
        } else {
            // Tapas normales y temerosas van encima de su taza
            int cupIndex = indexOfCup(number);
            if (cupIndex != -1) {
                stack.add(cupIndex + 1, lid);
                // Marca taza como tapada
                StackingItem cup = stack.get(cupIndex);
                if (cup instanceof Cup) {
                    ((Cup) cup).cover();
                }
                // Actualiza estado de tapa temerosa
                if (lid instanceof FearfulLid) {
                    ((FearfulLid) lid).setCoveringCup(true);
                }
            } else {
                stack.add(lid);
            }
        }

        lidNums.add(number);
        lastOk = true;
        redraw();
    }
    
    /**
     * Crea una tapa del subtipo especificado.
     */
    private Lid createLid(int number, String color, String subtype) {
        switch (subtype.toLowerCase()) {
            case "fearful":
            case "temerosa":
                return new FearfulLid(number, color);
            case "crazy":
            case "loca":
                return new CrazyLid(number, color);
            default:
                return new NormalLid(number, color);
        }
    }

    /**
     * Saca la taza superior de la torre.
     */
    public void popCup() {
        lastOk = false;
        
        if (stack.isEmpty()) {
            return;
        }

        for (int i = stack.size() - 1; i >= 0; i--) {
            StackingItem item = stack.get(i);
            if (item.getType().equals("cup")) {
                Cup cup = (Cup) item;
                
                // Verifica si la taza puede ser removida
                if (!cup.canBeRemoved()) {
                    return;
                }
                
                removeCupAt(i);
                cup.onExit(this);
                
                lastOk = true;
                redraw();
                return;
            }
        }
    }
    
    private void removeCupAt(int index) {
        StackingItem cup = stack.get(index);
        int number = cup.getNumber();

        // Si está tapada, también quita la tapa
        if (isLided(number)) {
            StackingItem lid = stack.get(index + 1);
            lid.makeInvisible();
            stack.remove(index + 1);
            lidNums.remove(number);
            
            if (cup instanceof Cup) {
                ((Cup) cup).uncover();
            }
        }

        cup.makeInvisible();
        stack.remove(index);
        cupNums.remove(number);
        cupColors.remove(number);
    }

    /**
     * Saca la tapa superior de la torre.
     */
    public void popLid() {
        lastOk = false;
        
        if (stack.isEmpty()) {
            return;
        }

        for (int i = stack.size() - 1; i >= 0; i--) {
            StackingItem item = stack.get(i);
            if (item.getType().equals("lid")) {
                Lid lid = (Lid) item;
                
                // Verifica si la tapa puede ser removida
                if (!lid.canBeRemoved(this)) {
                    return;
                }

                lid.makeInvisible();
                stack.remove(i);
                lidNums.remove(lid.getNumber());
                lid.onExit(this);

                lastOk = true;
                redraw();
                return;
            }
        }
    }

    /**
     * Remueve una taza específica por número.
     * @param number número de taza a remover
     */
    public void removeCup(int number) {
        lastOk = false;

        int idx = indexOfCup(number);
        if (idx == -1) {
            return;
        }
        
        Cup cup = (Cup) stack.get(idx);
        if (!cup.canBeRemoved()) {
            return;
        }

        removeCupAt(idx);
        cup.onExit(this);
        
        lastOk = true;
        redraw();
    }

    /**
     * Remueve una tapa específica por número.
     * @param number número de tapa a remover
     */
    public void removeLid(int number) {
        lastOk = false;

        for (int idx = 0; idx < stack.size(); idx++) {
            StackingItem it = stack.get(idx);
            if (it.getType().equals("lid") && it.getNumber() == number) {
                Lid lid = (Lid) it;
                
                if (!lid.canBeRemoved(this)) {
                    return;
                }
                
                it.makeInvisible();
                stack.remove(idx);
                lidNums.remove(number);
                lid.onExit(this);
                
                lastOk = true;
                redraw();
                return;
            }
        }
    }

    // ================================
    // MÉTODOS DE COMPORTAMIENTO ESPECIAL
    // ================================

    /**
     * Verifica si una taza existe en la torre.
     * @param number número de taza
     * @return true si la taza está en la torre
     */
    public boolean hasCup(int number) {
        return cupNums.contains(number);
    }
    
    /**
     * Verifica si una tapa está cubriendo su taza.
     * @param lid la tapa a verificar
     * @return true si está cubriendo su taza
     */
    public boolean isLidCoveringCup(Lid lid) {
        int cupIndex = indexOfCup(lid.getNumber());
        if (cupIndex == -1) return false;
        
        return (cupIndex + 1 < stack.size() && 
                stack.get(cupIndex + 1) == lid);
    }
    
    /**
     * Remueve todas las tapas por encima de una taza dada.
     * Usado por TazaAbridora.
     * @param cup la taza que entra
     */
    public void removeLidsAbove(Cup cup) {
        int insertIndex = findInsertIndex(cup);
        
        // Remueve tapas que bloquearían esta taza
        for (int i = insertIndex; i < stack.size(); i++) {
            StackingItem item = stack.get(i);
            if (item.getType().equals("lid")) {
                Lid lid = (Lid) item;
                lid.makeInvisible();
                stack.remove(i);
                lidNums.remove(lid.getNumber());
                i--; // Ajusta índice después de remover
            }
        }
    }
    
    /**
     * Desplaza objetos más pequeños cuando entra una taza jerárquica.
     * @param cup la taza jerárquica que entra
     * @return true si la taza llegó al fondo
     */
    public boolean displaceSmallerObjects(Cup cup) {
        int insertIndex = findInsertIndex(cup);
        boolean reachedBottom = (insertIndex == 0);
        
        // Mueve items más pequeños por encima de esta taza
        ArrayList<StackingItem> smallerItems = new ArrayList<>();
        for (int i = 0; i < insertIndex; i++) {
            StackingItem item = stack.get(i);
            if (item instanceof Cup) {
                Cup otherCup = (Cup) item;
                if (otherCup.isSmallerThan(cup)) {
                    smallerItems.add(item);
                }
            }
        }
        
        // Remueve items más pequeños de sus posiciones
        for (StackingItem item : smallerItems) {
            stack.remove(item);
        }
        
        // Los agrega por encima de la taza jerárquica
        int newPos = stack.indexOf(cup) + 1;
        for (StackingItem item : smallerItems) {
            stack.add(newPos, item);
            newPos++;
        }
        
        return reachedBottom;
    }

    // ================================
    // MÉTODOS DE CONSULTA
    // ================================

    /**
     * Retorna un arreglo con los elementos apilados.
     * @return arreglo 2D con [tipo, número, subtipo]
     */
    public String[][] stackingItems() {
        String[][] out = new String[stack.size()][3];
        for (int i = 0; i < stack.size(); i++) {
            out[i][0] = stack.get(i).getType();
            out[i][1] = String.valueOf(stack.get(i).getNumber());
            out[i][2] = stack.get(i).getSubtype();
        }
        return out;
    }

    /**
     * Retorna los números de tazas que están tapadas.
     * @return arreglo de números de taza
     */
    public int[] lidedCups() {
        ArrayList<Integer> nums = new ArrayList<>();

        for (int i = 0; i < stack.size() - 1; i++) {
            StackingItem a = stack.get(i);
            StackingItem b = stack.get(i + 1);

            if (a.getType().equals("cup") &&
                b.getType().equals("lid") &&
                a.getNumber() == b.getNumber()) {
                nums.add(a.getNumber());
            }
        }

        Collections.sort(nums, Collections.reverseOrder());
        
        int[] out = new int[nums.size()];
        for (int k = 0; k < nums.size(); k++) {
            out[k] = nums.get(k);
        }
        return out;
    }

    // ================================
    // MÉTODOS CICLO 2
    // ================================

    /**
     * Crea una nueva torre con n tazas normales.
     * @param n número de tazas
     */
    public void create(int n) {
        lastOk = false;

        clear();

        int cupHeight = 8;

        if (n * cupHeight > maxHeightCm) {
            return;
        }

        for (int i = 1; i <= n; i++) {
            String color = pickColor(i);
            Cup cup = new NormalCup(i, cupHeight, color);
            stack.add(cup);
            cupNums.add(i);
            cupColors.put(i, color);
        }

        lastOk = true;
        redraw();
    }
    
    /**
     * Limpia completamente la torre.
     */
    private void clear() {
        hideAllItems();
        stack.clear();
        cupNums.clear();
        lidNums.clear();
        cupColors.clear();
    }

    /**
     * Intercambia dos elementos en la torre.
     * @param pos1 primera posición
     * @param pos2 segunda posición
     */
    public void reorganize(int pos1, int pos2) {
        lastOk = false;

        if (pos1 < 0 || pos2 < 0 || 
            pos1 >= stack.size() || pos2 >= stack.size()) {
            return;
        }

        Collections.swap(stack, pos1, pos2);
        lastOk = true;
        redraw();
    }

    /**
     * Reorganiza la torre colocando cada tapa encima de su taza.
     */
    public void reorganize() {
        lastOk = false;

        for (int i = 0; i < stack.size(); i++) {
            StackingItem current = stack.get(i);

            if (current.getType().equals("cup") && current instanceof Cup) {
                Cup cup = (Cup) current;
                int number = cup.getNumber();

                for (int j = 0; j < stack.size(); j++) {
                    StackingItem item = stack.get(j);
                    if (item.getType().equals("lid") && item.getNumber() == number) {
                        stack.remove(j);
                        int insertPos = (j > i) ? i + 1 : i;
                        stack.add(insertPos, item);
                        cup.cover();
                        break;
                    }
                }
            }
        }

        lastOk = true;
        redraw();
    }

    /**
     * Consulta qué intercambio reduciría la altura de la torre.
     * @return arreglo con posiciones a intercambiar, o [-1, -1]
     */
    public int[] consult() {
        int currentHeight = getCurrentHeightCm();

        for (int i = 0; i < stack.size(); i++) {
            for (int j = i + 1; j < stack.size(); j++) {
                Collections.swap(stack, i, j);
                int newHeight = getCurrentHeightCm();
                Collections.swap(stack, i, j);

                if (newHeight < currentHeight) {
                    return new int[]{i, j};
                }
            }
        }

        return new int[]{-1, -1};
    }

    // ================================
    // MÉTODOS CICLO 3
    // ================================
    
    /**
     * Establece la posición de la torre en pantalla.
     * @param x coordenada X
     * @param y coordenada Y
     */
    public void setPosition(int x, int y) {
        this.xBase = x;
        this.yFloor = y;
        if (visible) {
            redraw();
        }
    }
    
    /**
     * Obtiene el número de elementos en la torre.
     * @return tamaño de la torre
     */
    public int size() {
        return stack.size();
    }

    // ================================
    // MÉTODOS AUXILIARES
    // ================================

    private void redraw() {
        if (visible) {
            hideAllItems();
        }

        int baseY = yFloor;

        for (StackingItem it : stack) {
            it.moveTo(xBase, baseY);
            if (visible) {
                it.makeVisible();
            }
            baseY -= it.getHeightCm() * Cup.PX_PER_CM;
        }

        drawCmMarks();
    }

    private void drawCmMarks() {
        hideAllMarks();

        if (!visible) {
            return;
        }

        int markX = xBase + 90;
        int baseY = yFloor;

        for (int cm = 0; cm <= maxHeightCm; cm++) {
            Rectangle mark = new Rectangle();
            mark.changeColor("black");

            int length = (cm % 5 == 0) ? 25 : 15;
            mark.changeSize(2, length);

            int y = baseY - (cm * Cup.PX_PER_CM);
            mark.moveTo(markX, y);

            mark.makeVisible();
            cmMarks.add(mark);
        }
    }

    private int indexOfCup(int number) {
        for (int idx = 0; idx < stack.size(); idx++) {
            StackingItem it = stack.get(idx);
            if (it.getType().equals("cup") && it.getNumber() == number) {
                return idx;
            }
        }
        return -1;
    }
    
    private int findInsertIndex(Cup cup) {
        int baseY = yFloor;
        int accumulatedHeight = 0;
        
        for (int i = 0; i < stack.size(); i++) {
            StackingItem item = stack.get(i);
            if (accumulatedHeight + cup.getHeightCm() <= maxHeightCm) {
                // Verifica si la taza cabe aquí
                return i;
            }
            accumulatedHeight += item.getHeightCm();
        }
        return stack.size();
    }

    private boolean isLided(int number) {
        int idx = indexOfCup(number);
        if (idx == -1) {
            return false;
        }

        if (idx + 1 < stack.size()) {
            StackingItem next = stack.get(idx + 1);
            return next.getType().equals("lid") && next.getNumber() == number;
        }
        return false;
    }

    private String pickColor(int number) {
        return COLORS[Math.abs(number) % COLORS.length];
    }

    /**
     * Sale de la aplicación.
     */
    public void exit() {
        System.exit(0);
    }

    /**
     * Imprime el estado actual de la torre.
     */
    public void printState() {
        System.out.println("ok=" + ok() + " height=" + getCurrentHeightCm());
        String[][] s = stackingItems();
        for (int i = 0; i < s.length; i++) {
            System.out.println(i + ": " + s[i][0] + " " + s[i][1] + " (" + s[i][2] + ")");
        }
        int[] lc = lidedCups();
        System.out.print("lidedCups: ");
        for (int n : lc) {
            System.out.print(n + " ");
        }
        System.out.println();
    }
}