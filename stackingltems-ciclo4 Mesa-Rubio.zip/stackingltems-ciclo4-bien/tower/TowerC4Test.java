package tower;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit tests for Cycle 4.
 * Tests the new cup and lid types.
 * 
 * @author DOPO-POOB Team
 * @version 4.0
 */
public class TowerC4Test {

    private Tower tower;

    /**
     * Sets up a clean tower before each test.
     */
    @Before
    public void setUp() {
        tower = new Tower(200, 100);
    }

    // =========================================================
    // NORMAL CUP TESTS
    // =========================================================

    @Test
    public void normalCupShouldBePushable() {
        tower.pushCup(1, 8, "normal");
        assertTrue(tower.ok());
        assertEquals(1, tower.size());
    }

    @Test
    public void normalCupShouldBeRemovable() {
        tower.pushCup(1, 8, "normal");
        tower.popCup();
        assertTrue(tower.ok());
        assertEquals(0, tower.size());
    }

    // =========================================================
    // OPENER CUP TESTS
    // =========================================================

    @Test
    public void openerCupShouldRemoveLidsAbove() {
        tower.pushCup(1, 8, "normal");
        tower.pushLid(2, "normal");
        tower.pushLid(3, "normal");
        
        tower.pushCup(4, 8, "opener");
        
        assertTrue(tower.ok());
        // Opener cup should have removed lids 2 and 3
    }

    @Test
    public void openerCupShouldBePushable() {
        tower.pushCup(1, 8, "opener");
        assertTrue(tower.ok());
    }

    // =========================================================
    // HIERARCHICAL CUP TESTS
    // =========================================================

    @Test
    public void hierarchicalCupShouldDisplaceSmallerCups() {
        tower.pushCup(1, 8, "normal");  // Small cup
        tower.pushCup(5, 8, "hierarchical");  // Larger number = larger cup
        
        assertTrue(tower.ok());
        // Hierarchical cup should displace the smaller cup
    }

    @Test
    public void hierarchicalCupShouldNotBeRemovableIfReachedBottom() {
        tower.pushCup(5, 8, "hierarchical");
        
        // Try to remove
        tower.popCup();
        
        // Should fail because it reached bottom
        assertFalse(tower.ok());
        assertEquals(1, tower.size());
    }

    // =========================================================
    // MAGIC CUP TESTS
    // =========================================================

    @Test
    public void magicCupShouldBePushable() {
        tower.pushCup(1, 8, "magic");
        assertTrue(tower.ok());
    }

    @Test
    public void magicCupShouldChangeColorWhenCovered() throws InterruptedException {
        tower.makeVisible();
        tower.pushCup(1, 8, "magic");
        tower.pushLid(1, "normal");
        
        assertTrue(tower.ok());
        
        // Wait for animation
        Thread.sleep(3000);
    }

    // =========================================================
    // FEARFUL LID TESTS
    // =========================================================

    @Test
    public void fearfulLidShouldNotEnterWithoutCup() {
        tower.pushLid(1, "fearful");
        
        assertFalse(tower.ok());
        assertEquals(0, tower.size());
    }

    @Test
    public void fearfulLidShouldEnterWithCup() {
        tower.pushCup(1, 8, "normal");
        tower.pushLid(1, "fearful");
        
        assertTrue(tower.ok());
        assertEquals(2, tower.size());
    }

    @Test
    public void fearfulLidShouldNotBeRemovableWhenCovering() {
        tower.pushCup(1, 8, "normal");
        tower.pushLid(1, "fearful");
        
        tower.popLid();
        
        assertFalse(tower.ok());
        assertEquals(2, tower.size());
    }

    // =========================================================
    // CRAZY LID TESTS
    // =========================================================

    @Test
    public void crazyLidShouldPositionAsBase() {
        tower.pushCup(1, 8, "normal");
        tower.pushLid(1, "crazy");
        
        assertTrue(tower.ok());
        
        String[][] items = tower.stackingItems();
        // Crazy lid should be below its cup
        assertEquals("lid", items[0][0]);
        assertEquals("crazy", items[0][2]);
    }

    // =========================================================
    // MIXED TESTS
    // =========================================================

    @Test
    public void mixedCupTypesShouldWorkTogether() {
        tower.pushCup(1, 8, "normal");
        tower.pushCup(2, 8, "opener");
        tower.pushCup(3, 8, "hierarchical");
        tower.pushCup(4, 8, "magic");
        
        assertTrue(tower.ok());
        assertEquals(4, tower.size());
    }

    @Test
    public void mixedLidTypesShouldWorkTogether() {
        tower.pushCup(1, 8, "normal");
        tower.pushCup(2, 8, "normal");
        tower.pushCup(3, 8, "normal");
        
        tower.pushLid(1, "normal");
        tower.pushLid(2, "fearful");
        tower.pushLid(3, "crazy");
        
        assertTrue(tower.ok());
    }
}