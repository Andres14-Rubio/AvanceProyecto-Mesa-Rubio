package tower;

import shapes.Rectangle;

/**
 * Clase abstracta que representa una taza genérica.
 * Proporciona la estructura base para todos los tipos de tazas.
 * 
 * 
 */
public abstract class Cup implements StackingItem {
    
    /** Número identificador de la taza */
    protected int number;
    
    /** Altura en centímetros */
    protected int heightCm;
    
    /** Altura en píxeles */
    protected int heightPx;
    
    /** Color original de la taza */
    protected String originalColor;
    
    /** Color actual de la taza */
    protected String currentColor;
    
    /** Indica si la taza está tapada */
    protected boolean covered;
    
    /** Indica si la taza está visible */
    protected boolean visible;
    
    /** Pared izquierda de la taza */
    protected Rectangle leftWall;
    
    /** Pared derecha de la taza */
    protected Rectangle rightWall;
    
    /** Base de la taza */
    protected Rectangle base;
    
    /** Posición X actual */
    protected int currentX;
    
    /** Posición Y actual (esquina superior) */
    protected int currentY;
    
    // Constantes de dibujo
    public static final int PX_PER_CM = 10;
    protected static final int CUP_WIDTH = 80;
    protected static final int WALL_THICKNESS = 10;
    protected static final int INITIAL_OFFSET_X = -70;
    protected static final int INITIAL_OFFSET_Y = -15;
    
    /**
     * Constructor para Taza.
     * @param number número identificador
     * @param heightCm altura en centímetros
     * @param color color inicial
     */
    public Cup(int number, int heightCm, String color) {
        this.number = number;
        this.heightCm = heightCm;
        this.heightPx = heightCm * PX_PER_CM;
        this.originalColor = color;
        this.currentColor = color;
        this.covered = false;
        this.visible = false;
        this.currentX = 0;
        this.currentY = 0;
        
        initializeWalls();
    }
    
    /**
     * Inicializa las paredes y base de la taza.
     */
    protected void initializeWalls() {
        leftWall = new Rectangle();
        rightWall = new Rectangle();
        base = new Rectangle();
        
        applyColorToWalls(currentColor);
        
        leftWall.changeSize(heightPx, WALL_THICKNESS);
        rightWall.changeSize(heightPx, WALL_THICKNESS);
        base.changeSize(WALL_THICKNESS, CUP_WIDTH);
        
        positionWallsRelative(0, 0);
    }
    
    /**
     * Aplica un color a todas las paredes.
     * @param color color a aplicar
     */
    protected void applyColorToWalls(String color) {
        leftWall.changeColor(color);
        rightWall.changeColor(color);
        base.changeColor(color);
    }
    
    /**
     * Posiciona las paredes relativamente a una posición base.
     * @param baseX coordenada X base
     * @param baseY coordenada Y base
     */
    protected void positionWallsRelative(int baseX, int baseY) {
        leftWall.moveTo(baseX + INITIAL_OFFSET_X, baseY + INITIAL_OFFSET_Y);
        rightWall.moveTo(baseX + INITIAL_OFFSET_X + (CUP_WIDTH - WALL_THICKNESS), 
                         baseY + INITIAL_OFFSET_Y);
        base.moveTo(baseX + INITIAL_OFFSET_X, 
                    baseY + INITIAL_OFFSET_Y + (heightPx - WALL_THICKNESS));
    }
    
    @Override
    public int getNumber() {
        return number;
    }
    
    @Override
    public String getType() {
        return "cup";
    }
    
    @Override
    public int getHeightCm() {
        return heightCm;
    }
    
    @Override
    public String getColor() {
        return currentColor;
    }
    
    @Override
    public void moveTo(int x, int baseY) {
        int topY = baseY - heightPx;
        positionWallsRelative(x, topY);
        currentX = x;
        currentY = topY;
    }
    
    @Override
    public void makeVisible() {
        if (!visible) {
            leftWall.makeVisible();
            rightWall.makeVisible();
            base.makeVisible();
            visible = true;
        }
    }
    
    @Override
    public void makeInvisible() {
        if (visible) {
            leftWall.makeInvisible();
            rightWall.makeInvisible();
            base.makeInvisible();
            visible = false;
        }
    }
    
    @Override
    public boolean isVisible() {
        return visible;
    }
    
    /**
     * Marca la taza como tapada (cambia su color a gris).
     */
    public void cover() {
        if (!covered) {
            covered = true;
            currentColor = "gray";
            applyColorToWalls(currentColor);
        }
    }
    
    /**
     * Quita la tapa visualmente, restaurando el color original.
     */
    public void uncover() {
        if (covered) {
            covered = false;
            currentColor = originalColor;
            applyColorToWalls(currentColor);
        }
    }
    
    /**
     * Verifica si la taza está tapada.
     * @return true si está tapada
     */
    public boolean isCovered() {
        return covered;
    }
    
    /**
     * Obtiene el color original de la taza.
     * @return color original
     */
    public String getOriginalColor() {
        return originalColor;
    }
    
    /**
     * Método abstracto para determinar si la taza puede ser removida.
     * @return true si puede ser removida
     */
    public abstract boolean canBeRemoved();
    
    /**
     * Método que se ejecuta cuando la taza entra a la torre.
     * Puede ser sobrescrito por subclases para comportamiento especial.
     * @param tower referencia a la torre
     * @return true si la entrada fue exitosa
     */
    public boolean onEnter(Tower tower) {
        return true;
    }
    
    /**
     * Método que se ejecuta cuando la taza es removida de la torre.
     * Puede ser sobrescrito por subclases para comportamiento especial.
     * @param tower referencia a la torre
     */
    public void onExit(Tower tower) {
        // Por defecto no hace nada
    }
    
    /**
     * Verifica si esta taza es más pequeña que otra taza.
     * @param other la otra taza
     * @return true si esta taza es más pequeña
     */
    public boolean isSmallerThan(Cup other) {
        return this.number < other.number;
    }
}