package tower;

/**
 * Tapa de tipo temerosa.
 * Si su taza compañera no está en la torre, no entra.
 * Si está tapando a su taza, no sale.
 * Se distingue visualmente por su color morado.
 * 
 
 */
public class FearfulLid extends Lid {
    
    /** Indica si la tapa está cubriendo su taza */
    private boolean coveringCup;
    
    /**
     * Constructor para TapaTemerosa.
     * @param number número identificador
     * @param color color de la tapa (ignorado, siempre es morado)
     */
    public FearfulLid(int number, String color) {
        super(number, "purple");
        this.coveringCup = false;
    }
    
    @Override
    public String getSubtype() {
        return "fearful";
    }
    
    @Override
    public boolean canEnter(Tower tower) {
        // Solo puede entrar si su taza está en la torre
        return tower.hasCup(number);
    }
    
    @Override
    public boolean canBeRemoved(Tower tower) {
        // No puede ser removida si está cubriendo su taza
        return !coveringCup;
    }
    
    @Override
    public void onEnter(Tower tower) {
        // Verifica si quedó posicionada directamente sobre su taza
        coveringCup = tower.isLidCoveringCup(this);
    }
    
    /**
     * Actualiza el estado de cobertura.
     * @param covering true si está cubriendo su taza
     */
    public void setCoveringCup(boolean covering) {
        this.coveringCup = covering;
    }
    
    /**
     * Verifica si la tapa está cubriendo su taza.
     * @return true si está cubriendo
     */
    public boolean isCoveringCup() {
        return coveringCup;
    }
}