package tower;

import shapes.Rectangle;

/**
 * Tapa de tipo loca.
 * En lugar de tapar a su taza, se ubica como base.
 * Se distingue visualmente por su color verde y patrón zigzag.
 *
 */
public class CrazyLid extends Lid {
    
    /** Elementos decorativos zigzag */
    private Rectangle zigzag1;
    private Rectangle zigzag2;
    
    /** Indica si está actuando como base */
    private boolean actingAsBase;
    
    /**
     * Constructor para TapaLoca.
     * @param number número identificador
     * @param color color de la tapa (ignorado, siempre es verde)
     */
    public CrazyLid(int number, String color) {
        super(number, "green");
        this.actingAsBase = false;
        initializeDecoration();
    }
    
    /**
     * Inicializa la decoración visual distintiva.
     */
    private void initializeDecoration() {
        zigzag1 = new Rectangle();
        zigzag1.changeColor("darkGreen");
        zigzag1.changeSize(3, 20);
        
        zigzag2 = new Rectangle();
        zigzag2.changeColor("darkGreen");
        zigzag2.changeSize(3, 20);
    }
    
    @Override
    protected void positionLidRelative(int baseX, int baseY) {
        super.positionLidRelative(baseX, baseY);
        
        if (zigzag1 != null) {
            zigzag1.moveTo(baseX + INITIAL_OFFSET_X + 10, baseY + INITIAL_OFFSET_Y - 3);
        }
        if (zigzag2 != null) {
            zigzag2.moveTo(baseX + INITIAL_OFFSET_X + 50, baseY + INITIAL_OFFSET_Y - 3);
        }
    }
    
    @Override
    public String getSubtype() {
        return "crazy";
    }
    
    @Override
    public boolean canEnter(Tower tower) {
        return true;
    }
    
    @Override
    public boolean canBeRemoved(Tower tower) {
        return true;
    }
    
    @Override
    public void onEnter(Tower tower) {
        // Las tapas locas van a la base de su taza en lugar de cubrirla
        actingAsBase = true;
    }
    
    /**
     * Verifica si la tapa está actuando como base.
     * @return true si está actuando como base
     */
    public boolean isActingAsBase() {
        return actingAsBase;
    }
    
    @Override
    public void makeVisible() {
        super.makeVisible();
        if (zigzag1 != null) {
            zigzag1.makeVisible();
        }
        if (zigzag2 != null) {
            zigzag2.makeVisible();
        }
    }
    
    @Override
    public void makeInvisible() {
        super.makeInvisible();
        if (zigzag1 != null) {
            zigzag1.makeInvisible();
        }
        if (zigzag2 != null) {
            zigzag2.makeInvisible();
        }
    }
}