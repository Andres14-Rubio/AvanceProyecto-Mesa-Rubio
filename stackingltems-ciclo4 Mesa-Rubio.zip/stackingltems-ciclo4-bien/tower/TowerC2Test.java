package tower;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Pruebas de unidad para el Ciclo 2.
 * 
 * Se prueban:
 * - create
 * - reorganize (intercambio)
 * - reorganize (tapar)
 * - consult
 * 
 * Las pruebas son invisibles (no se usa makeVisible).
 */
public class TowerC2Test {

    private Tower tower;

    /**
     * Se ejecuta antes de cada prueba.
     * Crea una torre limpia.
     */
    @Before
    public void setUp() {
        tower = new Tower(200, 100);
    }

    // =========================================================
    // CREATE
    // =========================================================

    @Test
    public void createShouldCreateNTazas() {

        tower.create(3);

        String[][] items = tower.stackingItems();

        assertEquals(3, items.length);
        assertEquals("cup", items[0][0]);
        assertEquals("1", items[0][1]);
        assertEquals("2", items[1][1]);
        assertEquals("3", items[2][1]);
        assertTrue(tower.ok());
    }

    @Test
    public void createShouldFailIfHeightExceeded() {

        // maxHeight = 100, cada taza mide 8 cm
        tower.create(20); // 20*8=160 > 100

        assertFalse(tower.ok());
        assertEquals(0, tower.stackingItems().length);
    }

    // =========================================================
    // REORGANIZE (SWAP)
    // =========================================================

    @Test
    public void reorganizeShouldSwapTwoPositions() {

        tower.create(3);

        tower.reorganize(0, 2);

        String[][] items = tower.stackingItems();

        assertEquals("3", items[0][1]);
        assertEquals("2", items[1][1]);
        assertEquals("1", items[2][1]);
        assertTrue(tower.ok());
    }

    @Test
    public void reorganizeShouldFailWithInvalidPositions() {

        tower.create(2);

        tower.reorganize(-1, 5);

        assertFalse(tower.ok());
    }

    // =========================================================
    // REORGANIZE (COVER)
    // =========================================================

    @Test
    public void reorganizeShouldCoverCupWhenLidExists() {

        tower.pushCup(1);
        tower.pushLid(1);

        tower.reorganize();

        int[] lided = tower.lidedCups();

        assertEquals(1, lided.length);
        assertEquals(1, lided[0]);
        assertTrue(tower.ok());
    }

    // =========================================================
    // CONSULT
    // =========================================================

    @Test
    public void consultShouldReturnMinusWhenNoImprovement() {

        tower.create(3);

        int[] result = tower.consult();

        assertEquals(-1, result[0]);
        assertEquals(-1, result[1]);
    }

}
