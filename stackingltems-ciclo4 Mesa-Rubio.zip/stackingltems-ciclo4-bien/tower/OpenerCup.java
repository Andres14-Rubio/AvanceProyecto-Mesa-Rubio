package tower;

import shapes.Rectangle;

/**
 * Taza de tipo abridora.
 * Al entrar a la torre, elimina todas las tapas que le impiden el paso.
 * Se distingue visualmente por tener un borde superior rojo.
 * 
 *
 */
public class OpenerCup extends Cup {
    
    /** Borde decorativo para distinción visual */
    private Rectangle topBorder;
    
    /**
     * Constructor para TazaAbridora.
     * @param number número identificador
     * @param heightCm altura en centímetros
     * @param color color inicial
     */
    public OpenerCup(int number, int heightCm, String color) {
        super(number, heightCm, color);
        initializeDecoration();
    }
    
    /**
     * Inicializa la decoración visual distintiva.
     */
    private void initializeDecoration() {
        topBorder = new Rectangle();
        topBorder.changeColor("red");
        topBorder.changeSize(5, CUP_WIDTH + 10);
    }
    
    @Override
    protected void positionWallsRelative(int baseX, int baseY) {
        super.positionWallsRelative(baseX, baseY);
        if (topBorder != null) {
            topBorder.moveTo(baseX + INITIAL_OFFSET_X - 5, baseY + INITIAL_OFFSET_Y - 5);
        }
    }
    
    @Override
    public String getSubtype() {
        return "opener";
    }
    
    @Override
    public boolean canBeRemoved() {
        return true;
    }
    
    @Override
    public boolean onEnter(Tower tower) {
        // Elimina todas las tapas que están por encima de esta taza
        tower.removeLidsAbove(this);
        return true;
    }
    
    @Override
    public void makeVisible() {
        super.makeVisible();
        if (topBorder != null) {
            topBorder.makeVisible();
        }
    }
    
    @Override
    public void makeInvisible() {
        super.makeInvisible();
        if (topBorder != null) {
            topBorder.makeInvisible();
        }
    }
}