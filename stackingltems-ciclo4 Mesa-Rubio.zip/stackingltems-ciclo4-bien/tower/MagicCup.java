package tower;

import shapes.Rectangle;
import shapes.Circle;

/**
 * Taza de tipo mágica (nuevo tipo propuesto).
 * Cuando está tapada por su tapa, cambia de color aleatoriamente cada 2 segundos.
 * Cuando se destapa, vuelve a su color original.
 * Se distingue visualmente por una estrella decorativa en el frente.
 * 

 */
public class MagicCup extends Cup {
    
    /** Estrella decorativa para distinción visual */
    private Circle star;
    
    /** Colores mágicos disponibles */
    private static final String[] MAGIC_COLORS = {
        "red", "blue", "green", "yellow", "magenta", "cyan", "orange", "pink"
    };
    
    /** Índice del color mágico actual */
    private int colorIndex;
    
    /** Hilo para la animación de color */
    private Thread animationThread;
    
    /** Indica si la animación está ejecutándose */
    private boolean animating;
    
    /**
     * Constructor para TazaMagica.
     * @param number número identificador
     * @param heightCm altura en centímetros
     * @param color color inicial
     */
    public MagicCup(int number, int heightCm, String color) {
        super(number, heightCm, color);
        this.colorIndex = 0;
        this.animating = false;
        initializeDecoration();
    }
    
    /**
     * Inicializa la decoración visual distintiva.
     */
    private void initializeDecoration() {
        star = new Circle();
        star.changeColor("yellow");
        star.changeSize(15);
    }
    
    @Override
    protected void positionWallsRelative(int baseX, int baseY) {
        super.positionWallsRelative(baseX, baseY);
        if (star != null) {
            star.moveTo(baseX + INITIAL_OFFSET_X + CUP_WIDTH / 2 - 7, 
                       baseY + INITIAL_OFFSET_Y + heightPx / 2 - 7);
        }
    }
    
    @Override
    public String getSubtype() {
        return "magic";
    }
    
    @Override
    public boolean canBeRemoved() {
        return true;
    }
    
    @Override
    public void cover() {
        super.cover();
        startColorAnimation();
    }
    
    @Override
    public void uncover() {
        super.uncover();
        stopColorAnimation();
        currentColor = originalColor;
        applyColorToWalls(currentColor);
    }
    
    /**
     * Inicia la animación de cambio de color.
     */
    private void startColorAnimation() {
        if (animating) {
            return;
        }
        
        animating = true;
        animationThread = new Thread(() -> {
            while (animating && covered) {
                colorIndex = (colorIndex + 1) % MAGIC_COLORS.length;
                currentColor = MAGIC_COLORS[colorIndex];
                applyColorToWalls(currentColor);
                
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    break;
                }
            }
        });
        animationThread.start();
    }
    
    /**
     * Detiene la animación de cambio de color.
     */
    private void stopColorAnimation() {
        animating = false;
        if (animationThread != null) {
            animationThread.interrupt();
            animationThread = null;
        }
    }
    
    @Override
    public void makeVisible() {
        super.makeVisible();
        if (star != null) {
            star.makeVisible();
        }
    }
    
    @Override
    public void makeInvisible() {
        super.makeInvisible();
        stopColorAnimation();
        if (star != null) {
            star.makeInvisible();
        }
    }
}