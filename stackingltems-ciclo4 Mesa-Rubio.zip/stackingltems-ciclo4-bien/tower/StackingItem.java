package tower;

/**
 * Interfaz para elementos que pueden ser apilados en la torre (tazas y tapas).
 * 
 *
 */
public interface StackingItem {
    
    /**
     * Obtiene el número identificador del elemento.
     * @return número identificador
     */
    int getNumber();
    
    /**
     * Obtiene el tipo de elemento.
     * @return "cup" o "lid"
     */
    String getType();
    
    /**
     * Obtiene el subtipo específico del elemento.
     * @return "normal", "opener", "hierarchical", "magic", "fearful", "crazy"
     */
    String getSubtype();
    
    /**
     * Obtiene la altura del elemento en centímetros.
     * @return altura en centímetros
     */
    int getHeightCm();
    
    /**
     * Mueve el elemento a una posición absoluta.
     * @param x coordenada X del borde izquierdo
     * @param baseY coordenada Y de la base del elemento
     */
    void moveTo(int x, int baseY);
    
    /**
     * Hace visible el elemento.
     */
    void makeVisible();
    
    /**
     * Hace invisible el elemento.
     */
    void makeInvisible();
    
    /**
     * Verifica si el elemento está visible.
     * @return true si está visible
     */
    boolean isVisible();
    
    /**
     * Obtiene el color actual del elemento.
     * @return cadena con el color
     */
    String getColor();
}