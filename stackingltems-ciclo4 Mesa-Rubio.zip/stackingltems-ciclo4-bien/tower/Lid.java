package tower;

import shapes.Rectangle;

/**
 * Clase abstracta que representa una tapa genérica.
 * Proporciona la estructura base para todos los tipos de tapas.
 * 
 
 */
public abstract class Lid implements StackingItem {
    
    /** Número identificador (coincide con su taza) */
    protected int number;
    
    /** Color de la tapa */
    protected String color;
    
    /** Indica si la tapa está visible */
    protected boolean visible;
    
    /** Rectángulo que representa la tapa */
    protected Rectangle lidRect;
    
    /** Posición X actual */
    protected int currentX;
    
    /** Posición Y actual */
    protected int currentY;
    
    // Constantes de dibujo
    protected static final int LID_WIDTH = 80;
    protected static final int LID_HEIGHT_PX = Cup.PX_PER_CM;
    protected static final int INITIAL_OFFSET_X = -70;
    protected static final int INITIAL_OFFSET_Y = -15;
    
    /**
     * Constructor para Tapa.
     * @param number número identificador (debe coincidir con su taza)
     * @param color color de la tapa
     */
    public Lid(int number, String color) {
        this.number = number;
        this.color = color;
        this.visible = false;
        this.currentX = 0;
        this.currentY = 0;
        
        initializeLid();
    }
    
    /**
     * Inicializa el rectángulo de la tapa.
     */
    protected void initializeLid() {
        lidRect = new Rectangle();
        lidRect.changeColor(color);
        lidRect.changeSize(LID_HEIGHT_PX, LID_WIDTH);
        positionLidRelative(0, 0);
    }
    
    /**
     * Posiciona la tapa relativamente a una posición base.
     * @param baseX coordenada X base
     * @param baseY coordenada Y base
     */
    protected void positionLidRelative(int baseX, int baseY) {
        lidRect.moveTo(baseX + INITIAL_OFFSET_X, baseY + INITIAL_OFFSET_Y);
    }
    
    @Override
    public int getNumber() {
        return number;
    }
    
    @Override
    public String getType() {
        return "lid";
    }
    
    @Override
    public int getHeightCm() {
        return 1;
    }
    
    @Override
    public String getColor() {
        return color;
    }
    
    @Override
    public void moveTo(int x, int baseY) {
        int topY = baseY - LID_HEIGHT_PX;
        positionLidRelative(x, topY);
        currentX = x;
        currentY = topY;
    }
    
    @Override
    public void makeVisible() {
        if (!visible) {
            lidRect.makeVisible();
            visible = true;
        }
    }
    
    @Override
    public void makeInvisible() {
        if (visible) {
            lidRect.makeInvisible();
            visible = false;
        }
    }
    
    @Override
    public boolean isVisible() {
        return visible;
    }
    
    /**
     * Determina si la tapa puede entrar a la torre.
     * @param tower referencia a la torre
     * @return true si puede entrar
     */
    public abstract boolean canEnter(Tower tower);
    
    /**
     * Determina si la tapa puede ser removida de la torre.
     * @param tower referencia a la torre
     * @return true si puede ser removida
     */
    public abstract boolean canBeRemoved(Tower tower);
    
    /**
     * Método que se ejecuta cuando la tapa entra a la torre.
     * @param tower referencia a la torre
     */
    public void onEnter(Tower tower) {
        // Por defecto no hace nada
    }
    
    /**
     * Método que se ejecuta cuando la tapa es removida de la torre.
     * @param tower referencia a la torre
     */
    public void onExit(Tower tower) {
        // Por defecto no hace nada
    }
}