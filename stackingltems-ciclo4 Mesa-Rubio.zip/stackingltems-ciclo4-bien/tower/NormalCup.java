package tower;

/**
 * Taza de tipo normal.
 * Comportamiento estándar sin características especiales.
 *
 */
public class NormalCup extends Cup {
    
    /**
     * Constructor para TazaNormal.
     * @param number número identificador
     * @param heightCm altura en centímetros
     * @param color color inicial
     */
    public NormalCup(int number, int heightCm, String color) {
        super(number, heightCm, color);
    }
    
    @Override
    public String getSubtype() {
        return "normal";
    }
    
    @Override
    public boolean canBeRemoved() {
        return true;
    }
}