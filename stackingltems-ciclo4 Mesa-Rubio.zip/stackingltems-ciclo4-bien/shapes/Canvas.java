package shapes;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.*;

/**
 * Canvas es una clase que permite dibujar figuras gráficas simples sobre un lienzo.
 * Esta es una modificación del Canvas de propósito general, especialmente hecha para
 * el ejemplo de "shapes" de BlueJ.
 *
 * @author Bruce Quig
 * @author Michael Kolling (mik)
 * @version 1.6 (shapes)
 */
public class Canvas {
    
    private static Canvas canvasSingleton;

    /**
     * Método de fábrica para obtener el objeto singleton del canvas.
     * @return la instancia única del Canvas
     */
    public static Canvas getCanvas() {
        if (canvasSingleton == null) {
            canvasSingleton = new Canvas("BlueJ Shapes Demo", 500, 500, Color.white);
        }
        canvasSingleton.setVisible(true);
        return canvasSingleton;
    }

    // ----- parte de instancia -----

    private JFrame frame;
    private CanvasPane canvas;
    private Graphics2D graphic;
    private Color backgroundColour;
    private Image canvasImage;
    private List<Object> objects;
    private HashMap<Object, ShapeDescription> shapes;
    
    /**
     * Crea un nuevo Canvas.
     * @param title  título que aparecerá en el marco del Canvas
     * @param width  ancho deseado para el canvas
     * @param height alto deseado para el canvas
     * @param bgColour  color de fondo deseado para el canvas
     */
    private Canvas(String title, int width, int height, Color bgColour) {
        frame = new JFrame();
        canvas = new CanvasPane();
        frame.setContentPane(canvas);
        frame.setTitle(title);
        canvas.setPreferredSize(new Dimension(width, height));
        backgroundColour = bgColour;
        frame.pack();
        objects = new ArrayList<Object>();
        shapes = new HashMap<Object, ShapeDescription>();
    }

    /**
     * Establece la visibilidad del canvas y lo trae al frente de la pantalla
     * cuando se hace visible. Este método también puede usarse para traer un
     * canvas ya visible al frente de otras ventanas.
     * @param visible valor booleano que representa la visibilidad deseada del canvas
     */
    public void setVisible(boolean visible) {
        if (graphic == null) {
            Dimension size = canvas.getSize();
            canvasImage = canvas.createImage(size.width, size.height);
            graphic = (Graphics2D) canvasImage.getGraphics();
            graphic.setColor(backgroundColour);
            graphic.fillRect(0, 0, size.width, size.height);
            graphic.setColor(Color.black);
        }
        frame.setVisible(visible);
    }

    /**
     * Dibuja una figura dada sobre el canvas.
     * @param referenceObject un objeto para definir la identidad de esta figura
     * @param color el color de la figura
     * @param shape la figura a ser dibujada en el canvas
     */
    public void draw(Object referenceObject, String color, Shape shape) {
        objects.remove(referenceObject);
        objects.add(referenceObject);
        shapes.put(referenceObject, new ShapeDescription(shape, color));
        redraw();
    }
 
    /**
     * Borra una figura dada de la pantalla.
     * @param referenceObject el objeto figura a ser borrado
     */
    public void erase(Object referenceObject) {
        objects.remove(referenceObject);
        shapes.remove(referenceObject);
        redraw();
    }

    /**
     * Establece el color de primer plano del Canvas.
     * @param colorString el nuevo color para el primer plano del Canvas
     */
    public void setForegroundColor(String colorString) {
        if (colorString.equals("red") || colorString.equals("rojo"))
            graphic.setColor(Color.red);
        else if (colorString.equals("black") || colorString.equals("negro"))
            graphic.setColor(Color.black);
        else if (colorString.equals("blue") || colorString.equals("azul"))
            graphic.setColor(Color.blue);
        else if (colorString.equals("yellow") || colorString.equals("amarillo"))
            graphic.setColor(Color.yellow);
        else if (colorString.equals("green") || colorString.equals("verde"))
            graphic.setColor(Color.green);
        else if (colorString.equals("magenta"))
            graphic.setColor(Color.magenta);
        else if (colorString.equals("white") || colorString.equals("blanco"))
            graphic.setColor(Color.white);
        else if (colorString.equals("gray") || colorString.equals("gris"))
            graphic.setColor(Color.gray);
        else if (colorString.equals("orange") || colorString.equals("naranja"))
            graphic.setColor(Color.orange);
        else if (colorString.equals("pink") || colorString.equals("rosado"))
            graphic.setColor(Color.pink);
        else if (colorString.equals("cyan"))
            graphic.setColor(Color.cyan);
        else if (colorString.equals("purple") || colorString.equals("morado"))
            graphic.setColor(Color.magenta);
        else if (colorString.equals("darkGreen") || colorString.equals("verdeOscuro"))
            graphic.setColor(Color.green.darker());
        else
            graphic.setColor(Color.black);
    }

    /**
     * Espera un número especificado de milisegundos antes de finalizar.
     * Esto proporciona una manera fácil de especificar una pequeña demora que
     * puede usarse al producir animaciones.
     * @param milliseconds el número de milisegundos a esperar
     */
    public void wait(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (Exception e) {
            // ignorando excepción por el momento
        }
    }

    /**
     * Redibuja todas las figuras actualmente en el Canvas.
     */
    private void redraw() {
        eraseCanvas();
        for (Iterator i = objects.iterator(); i.hasNext(); ) {
            shapes.get(i.next()).draw(graphic);
        }
        canvas.repaint();
    }
       
    /**
     * Borra todo el canvas. (No repinta.)
     */
    private void eraseCanvas() {
        Color original = graphic.getColor();
        graphic.setColor(backgroundColour);
        Dimension size = canvas.getSize();
        graphic.fill(new java.awt.Rectangle(0, 0, size.width, size.height));
        graphic.setColor(original);
    }

    /************************************************************************
     * Clase interna CanvasPane - el componente canvas real contenido en el
     * marco Canvas. Es esencialmente un JPanel con capacidad adicional de
     * refrescar la imagen dibujada en él.
     */
    private class CanvasPane extends JPanel {
        public void paint(Graphics g) {
            g.drawImage(canvasImage, 0, 0, null);
        }
    }
    
    /************************************************************************
     * Clase interna ShapeDescription - almacena la información de una figura.
     */
    private class ShapeDescription {
        private Shape shape;
        private String colorString;

        public ShapeDescription(Shape shape, String color) {
            this.shape = shape;
            colorString = color;
        }

        public void draw(Graphics2D graphic) {
            setForegroundColor(colorString);
            graphic.draw(shape);
            graphic.fill(shape);
        }
    }
}