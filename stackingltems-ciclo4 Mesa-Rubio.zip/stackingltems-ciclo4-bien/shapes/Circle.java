package shapes;

import java.awt.*;
import java.awt.geom.*;

/**
 * Un círculo que puede ser manipulado y que se dibuja a sí mismo sobre un canvas.
 * Extiende la clase abstracta Figure.
 * 
 * @author Michael Kolling y David J. Barnes (Modificado)
 * @version 2.0
 */
public class Circle extends Figure {
    
    /** Valor de PI */
    public static final double PI = 3.1416;
    
    private int diameter;
    
    /**
     * Crea un nuevo círculo en la posición predeterminada con color predeterminado.
     */
    public Circle() {
        this(20, 15, 30, "blue");
    }
    
    /**
     * Crea un nuevo círculo con parámetros especificados.
     * @param x posición X
     * @param y posición Y
     * @param diameter diámetro del círculo
     * @param color color del círculo
     */
    public Circle(int x, int y, int diameter, String color) {
        super(x, y, color);
        this.diameter = diameter;
    }
    
    /**
     * Cambia el tamaño del círculo.
     * @param newDiameter el nuevo diámetro en píxeles (debe ser >= 0)
     */
    public void changeSize(int newDiameter) {
        erase();
        diameter = newDiameter;
        draw();
    }
    
    /**
     * Obtiene el diámetro actual.
     * @return diámetro en píxeles
     */
    public int getDiameter() {
        return diameter;
    }
    
    @Override
    protected void draw() {
        if (isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color, getShape());
            canvas.wait(10);
        }
    }
    
    @Override
    protected Shape getShape() {
        return new Ellipse2D.Double(xPosition, yPosition, diameter, diameter);
    }
    
    /**
     * Mueve lentamente el círculo horizontalmente.
     * @param distance la distancia deseada en píxeles
     */
    public void slowMoveHorizontal(int distance) {
        int delta = distance < 0 ? -1 : 1;
        int absDistance = Math.abs(distance);
        
        for (int i = 0; i < absDistance; i++) {
            xPosition += delta;
            draw();
        }
    }
    
    /**
     * Mueve lentamente el círculo verticalmente.
     * @param distance la distancia deseada en píxeles
     */
    public void slowMoveVertical(int distance) {
        int delta = distance < 0 ? -1 : 1;
        int absDistance = Math.abs(distance);
        
        for (int i = 0; i < absDistance; i++) {
            yPosition += delta;
            draw();
        }
    }
}