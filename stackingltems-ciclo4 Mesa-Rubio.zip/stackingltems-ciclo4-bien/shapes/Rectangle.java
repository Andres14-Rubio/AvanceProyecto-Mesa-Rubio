package shapes;

import java.awt.*;

/**
 * Un rectángulo que puede ser manipulado y que se dibuja a sí mismo sobre un canvas.
 * Extiende la clase abstracta Figure.
 * 
 * @author Michael Kolling y David J. Barnes (Modificado)
 * @version 2.0
 */
public class Rectangle extends Figure {
    
    /** Número de lados de un rectángulo */
    public static final int EDGES = 4;
    
    private int height;
    private int width;
    
    /**
     * Crea un nuevo rectángulo en la posición predeterminada con color predeterminado.
     */
    public Rectangle() {
        this(70, 15, 30, 40, "magenta");
    }
    
    /**
     * Crea un nuevo rectángulo con parámetros especificados.
     * @param x posición X
     * @param y posición Y
     * @param height altura del rectángulo
     * @param width ancho del rectángulo
     * @param color color del rectángulo
     */
    public Rectangle(int x, int y, int height, int width, String color) {
        super(x, y, color);
        this.height = height;
        this.width = width;
    }
    
    /**
     * Cambia el tamaño al nuevo tamaño especificado.
     * @param newHeight la nueva altura en píxeles (debe ser >= 0)
     * @param newWidth el nuevo ancho en píxeles (debe ser >= 0)
     */
    public void changeSize(int newHeight, int newWidth) {
        erase();
        height = newHeight;
        width = newWidth;
        draw();
    }
    
    /**
     * Obtiene la altura actual.
     * @return altura en píxeles
     */
    public int getHeight() {
        return height;
    }
    
    /**
     * Obtiene el ancho actual.
     * @return ancho en píxeles
     */
    public int getWidth() {
        return width;
    }
    
    @Override
    protected void draw() {
        if (isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color, getShape());
            canvas.wait(10);
        }
    }
    
    @Override
    protected Shape getShape() {
        return new java.awt.Rectangle(xPosition, yPosition, width, height);
    }
    
    /**
     * Mueve lentamente el rectángulo horizontalmente.
     * @param distance la distancia deseada en píxeles
     */
    public void slowMoveHorizontal(int distance) {
        int delta = distance < 0 ? -1 : 1;
        int absDistance = Math.abs(distance);
        
        for (int i = 0; i < absDistance; i++) {
            xPosition += delta;
            draw();
        }
    }
    
    /**
     * Mueve lentamente el rectángulo verticalmente.
     * @param distance la distancia deseada en píxeles
     */
    public void slowMoveVertical(int distance) {
        int delta = distance < 0 ? -1 : 1;
        int absDistance = Math.abs(distance);
        
        for (int i = 0; i < absDistance; i++) {
            yPosition += delta;
            draw();
        }
    }
}