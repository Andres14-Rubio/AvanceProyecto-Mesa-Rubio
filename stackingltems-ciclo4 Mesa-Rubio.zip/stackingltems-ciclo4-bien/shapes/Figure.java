package shapes;

import java.awt.*;

/**
 * Clase abstracta base para todas las figuras dibujables.
 * Proporciona atributos y métodos comunes para formas geométricas.
 * 
 * 
 */
public abstract class Figure {
    
    /** Posición X de la figura */
    protected int xPosition;
    
    /** Posición Y de la figura */
    protected int yPosition;
    
    /** Color de la figura */
    protected String color;
    
    /** Indica si la figura está visible */
    protected boolean isVisible;
    
    /**
     * Constructor para Figura.
     * @param x posición X inicial
     * @param y posición Y inicial
     * @param color color inicial
     */
    public Figure(int x, int y, String color) {
        this.xPosition = x;
        this.yPosition = y;
        this.color = color;
        this.isVisible = false;
    }
    
    /**
     * Hace visible esta figura. Si ya estaba visible, no hace nada.
     */
    public void makeVisible() {
        isVisible = true;
        draw();
    }
    
    /**
     * Hace invisible esta figura. Si ya estaba invisible, no hace nada.
     */
    public void makeInvisible() {
        erase();
        isVisible = false;
    }
    
    /**
     * Mueve la figura horizontalmente.
     * @param distance la distancia deseada en píxeles
     */
    public void moveHorizontal(int distance) {
        erase();
        xPosition += distance;
        draw();
    }
    
    /**
     * Mueve la figura verticalmente.
     * @param distance la distancia deseada en píxeles
     */
    public void moveVertical(int distance) {
        erase();
        yPosition += distance;
        draw();
    }
    
    /**
     * Mueve la figura a una posición absoluta.
     * @param x nueva coordenada X
     * @param y nueva coordenada Y
     */
    public void moveTo(int x, int y) {
        erase();
        xPosition = x;
        yPosition = y;
        draw();
    }
    
    /**
     * Cambia el color de la figura.
     * @param newColor el nuevo color
     */
    public void changeColor(String newColor) {
        color = newColor;
        draw();
    }
    
    /**
     * Obtiene el color actual.
     * @return cadena con el color actual
     */
    public String getColor() {
        return color;
    }
    
    /**
     * Obtiene la posición X actual.
     * @return posición X
     */
    public int getXPosition() {
        return xPosition;
    }
    
    /**
     * Obtiene la posición Y actual.
     * @return posición Y
     */
    public int getYPosition() {
        return yPosition;
    }
    
    /**
     * Verifica si la figura está visible.
     * @return true si está visible
     */
    public boolean isVisible() {
        return isVisible;
    }
    
    /**
     * Método abstracto para dibujar la forma específica.
     * Debe ser implementado por las subclases.
     */
    protected abstract void draw();
    
    /**
     * Borra la figura de la pantalla.
     */
    protected void erase() {
        if (isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
    
    /**
     * Obtiene la representación Shape de AWT de esta figura.
     * @return objeto Shape para dibujar
     */
    protected abstract Shape getShape();
    
    /**
     * Mueve la figura 20 píxeles a la derecha.
     */
    public void moveRight() {
        moveHorizontal(20);
    }
    
    /**
     * Mueve la figura 20 píxeles a la izquierda.
     */
    public void moveLeft() {
        moveHorizontal(-20);
    }
    
    /**
     * Mueve la figura 20 píxeles hacia arriba.
     */
    public void moveUp() {
        moveVertical(-20);
    }
    
    /**
     * Mueve la figura 20 píxeles hacia abajo.
     */
    public void moveDown() {
        moveVertical(20);
    }
}